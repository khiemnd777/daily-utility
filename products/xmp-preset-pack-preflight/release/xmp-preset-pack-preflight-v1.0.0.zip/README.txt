XMP PRESET PACK PREFLIGHT 1.0.0

Open index.html in a current desktop browser.
Choose one ZIP or up to 500 .xmp files, review every finding,
then export CSV or self-contained HTML evidence.

SAFETY LIMITS
- ZIP: 50 MB compressed
- Expanded release content: 100 MB
- XMP files: 500 per scan
- Individual XMP file: 2 MB
- Archive entries: 5,000
- Path length: 240 characters

PRIVACY
All parsing and SHA-256 hashing happen locally. There is no upload, account,
telemetry, analytics, persistent storage, or outbound network request.
Input files are never modified.

BOUNDARIES
This is static structural preflight, not preset import, photo rendering, repair,
rights advice, or Adobe certification. Test representative presets in every
Lightroom, Camera Raw, operating-system, camera, and profile workflow you claim.

SUPPORT
See SUPPORT.txt or reply to your Gumroad receipt.
Normal response target: two business days.
