CUBE LUT PACK PREFLIGHT 1.0.0

Open index.html in a current desktop browser.
Choose one ZIP or up to 100 .cube files, review every blocker and review finding,
then export CSV or self-contained HTML evidence.

SAFETY LIMITS
- ZIP: 100 MB compressed
- Expanded release content: 150 MB
- CUBE LUT files: 100 per scan
- Individual LUT: 20 MB
- Archive entries: 1,000
- Path length: 240 characters

PRIVACY
All parsing and SHA-256 hashing happen locally. The application has no upload,
account, telemetry, analytics, persistent storage, or outbound network request.
Input files are never modified.

BOUNDARIES
This is structural preflight, not a color-accuracy or compatibility guarantee.
It does not render, repair, resample, convert, install, or judge LUTs. A static pass
does not replace representative testing in every application or device you claim to support.

SUPPORT
Reply to your Gumroad receipt for purchase access or documented core-functionality support.
Never send payment data, credentials, customer information, confidential footage,
or LUT files you are not permitted to share.
Normal response target: two business days.
