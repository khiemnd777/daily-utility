MIDI PACK PREFLIGHT 1.0.0

Open index.html in a current desktop browser.
Choose one ZIP or up to 2,000 .mid/.midi files, review every finding,
then export CSV or self-contained HTML evidence.

SAFETY LIMITS
- ZIP: 100 MB compressed
- Expanded release content: 150 MB
- MIDI files: 2,000 per scan
- Individual MIDI file: 10 MB
- Archive entries: 5,000
- Path length: 240 characters

PRIVACY
All parsing and SHA-256 hashing happen locally. There is no upload, account,
telemetry, analytics, persistent storage, or outbound network request.
Input files are never modified.

BOUNDARIES
This is structural preflight, not repair, musical review, rights advice, or a
universal compatibility guarantee. Test representative files in every DAW,
plugin, instrument, or hardware device you claim to support.

SUPPORT
See SUPPORT.txt or reply to your Gumroad receipt.
Normal response target: two business days.
