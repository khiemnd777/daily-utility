SVG BUNDLE PREFLIGHT 1.0.0

Open index.html in a current desktop browser.
Choose one ZIP archive or one or more SVG files, review the findings,
then export a CSV or self-contained HTML release report.

All parsing and hashing happen locally. The app has no account, upload,
analytics, telemetry, or network request.

Safety limits:
- One ZIP up to 50 MB compressed
- Up to 100 MB expanded SVG content
- Up to 500 SVG files
- Up to 2 MB per SVG
- Paths up to 240 characters

The utility does not repair files, recurse into nested archives, validate
DXF/EPS/PNG, test physical cuts, or provide licensing advice. A static pass
does not replace a representative import and real test cut.

Not affiliated with or endorsed by Cricut or Etsy.
