PRESENTATION TEMPLATE PREFLIGHT 1.0.0

Open index.html in a current desktop browser.
Choose one final .pptx or .potx file, review every blocker and warning,
then export the CSV and self-contained HTML release reports.

All parsing and SHA-256 hashing happen locally. The app has no account,
upload, analytics, telemetry, remote fetch, or persistent storage.

Safety limits:
- One presentation up to 100 MB
- Up to 5,000 package parts
- Up to 250 MB declared expanded content
- Up to 5 MB per XML or relationships part
- Package paths up to 260 characters

This utility does not render or repair slides, prove font licensing,
certify accessibility, execute macros or embedded objects, or guarantee
PowerPoint compatibility. Perform a visual delivery check before release.

Not affiliated with or endorsed by Microsoft.
